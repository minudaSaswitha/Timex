﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Timex
{
    public partial class Login : MetroFramework.Forms.MetroForm
    {
        public string user { get; set; }
        public bool loginflag { get; set; }
        public Login()
        {
            InitializeComponent();
            loginflag = false;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            string user = metroTextBox1.Text;
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
