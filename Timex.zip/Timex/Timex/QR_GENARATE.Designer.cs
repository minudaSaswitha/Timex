﻿namespace Timex
{
    partial class QR_GENARATE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OLD_QR = new System.Windows.Forms.PictureBox();
            this.OLD_QRSAVE = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.OLD_QR)).BeginInit();
            this.SuspendLayout();
            // 
            // OLD_QR
            // 
            this.OLD_QR.Location = new System.Drawing.Point(57, 127);
            this.OLD_QR.Name = "OLD_QR";
            this.OLD_QR.Size = new System.Drawing.Size(300, 300);
            this.OLD_QR.TabIndex = 0;
            this.OLD_QR.TabStop = false;
            // 
            // OLD_QRSAVE
            // 
            this.OLD_QRSAVE.Location = new System.Drawing.Point(57, 91);
            this.OLD_QRSAVE.Name = "OLD_QRSAVE";
            this.OLD_QRSAVE.Size = new System.Drawing.Size(75, 23);
            this.OLD_QRSAVE.TabIndex = 1;
            this.OLD_QRSAVE.Text = "Save";
            // 
            // QR_GENARATE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 450);
            this.Controls.Add(this.OLD_QRSAVE);
            this.Controls.Add(this.OLD_QR);
            this.Name = "QR_GENARATE";
            this.Text = "QR_GENARATE";
            this.Load += new System.EventHandler(this.QR_GENARATE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.OLD_QR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox OLD_QR;
        private MetroFramework.Controls.MetroButton OLD_QRSAVE;
    }
}