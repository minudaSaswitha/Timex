﻿namespace Timex
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.combodepartment = new MetroFramework.Controls.MetroComboBox();
            this.tbemail = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.tbname = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.tbID = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.NEW_QR = new System.Windows.Forms.PictureBox();
            this.NEW_DEPARTMENT = new MetroFramework.Controls.MetroComboBox();
            this.NEW_EMAIL = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.NEW_NAME = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.NEW_ID = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.QR_SAVE = new MetroFramework.Controls.MetroButton();
            this.NEW_ADDbtn = new MetroFramework.Controls.MetroButton();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.Emails = new System.Windows.Forms.ListBox();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroButton7 = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NEW_QR)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.metroTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.metroTabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Controls.Add(this.metroTabPage5);
            this.metroTabControl1.Controls.Add(this.metroTabPage6);
            this.metroTabControl1.Controls.Add(this.metroTabPage7);
            this.metroTabControl1.Controls.Add(this.metroTabPage8);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(20, 60);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 6;
            this.metroTabControl1.Size = new System.Drawing.Size(815, 463);
            this.metroTabControl1.TabIndex = 0;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Introduction";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage6.TabIndex = 5;
            this.metroTabPage6.Text = "Covid_Tracking";
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroButton4);
            this.metroTabPage2.Controls.Add(this.dataGridView1);
            this.metroTabPage2.Controls.Add(this.metroButton3);
            this.metroTabPage2.Controls.Add(this.metroButton2);
            this.metroTabPage2.Controls.Add(this.metroButton1);
            this.metroTabPage2.Controls.Add(this.combodepartment);
            this.metroTabPage2.Controls.Add(this.tbemail);
            this.metroTabPage2.Controls.Add(this.metroLabel4);
            this.metroTabPage2.Controls.Add(this.metroLabel3);
            this.metroTabPage2.Controls.Add(this.tbname);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.Controls.Add(this.tbID);
            this.metroTabPage2.Controls.Add(this.metroLabel1);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Manage Employee";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.Click += new System.EventHandler(this.metroTabPage2_Click);
            // 
            // metroButton4
            // 
            this.metroButton4.Location = new System.Drawing.Point(207, 304);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(75, 23);
            this.metroButton4.TabIndex = 7;
            this.metroButton4.Text = "Genarate_QR";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(393, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(411, 371);
            this.dataGridView1.TabIndex = 6;
            // 
            // metroButton3
            // 
            this.metroButton3.Location = new System.Drawing.Point(301, 49);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(75, 23);
            this.metroButton3.TabIndex = 5;
            this.metroButton3.Text = "Search";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(109, 304);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 5;
            this.metroButton2.Text = "Delete";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(9, 304);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 5;
            this.metroButton1.Text = "Update";
            // 
            // combodepartment
            // 
            this.combodepartment.FormattingEnabled = true;
            this.combodepartment.ItemHeight = 23;
            this.combodepartment.Location = new System.Drawing.Point(91, 156);
            this.combodepartment.Name = "combodepartment";
            this.combodepartment.Size = new System.Drawing.Size(191, 29);
            this.combodepartment.TabIndex = 4;
            // 
            // tbemail
            // 
            this.tbemail.Location = new System.Drawing.Point(91, 209);
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(191, 23);
            this.tbemail.TabIndex = 3;
            this.tbemail.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(4, 212);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(74, 19);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Email_ADD";
            this.metroLabel4.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(4, 160);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(80, 19);
            this.metroLabel3.TabIndex = 2;
            this.metroLabel3.Text = "Department";
            this.metroLabel3.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(91, 105);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(191, 23);
            this.tbname.TabIndex = 3;
            this.tbname.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(4, 108);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(45, 19);
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "Name";
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(91, 50);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(191, 23);
            this.tbID.TabIndex = 3;
            this.tbID.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(4, 53);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(76, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "ID_Number";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.NEW_QR);
            this.metroTabPage3.Controls.Add(this.NEW_DEPARTMENT);
            this.metroTabPage3.Controls.Add(this.NEW_EMAIL);
            this.metroTabPage3.Controls.Add(this.metroLabel8);
            this.metroTabPage3.Controls.Add(this.metroLabel7);
            this.metroTabPage3.Controls.Add(this.NEW_NAME);
            this.metroTabPage3.Controls.Add(this.metroLabel6);
            this.metroTabPage3.Controls.Add(this.NEW_ID);
            this.metroTabPage3.Controls.Add(this.metroLabel5);
            this.metroTabPage3.Controls.Add(this.QR_SAVE);
            this.metroTabPage3.Controls.Add(this.NEW_ADDbtn);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "New Registration";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            // 
            // NEW_QR
            // 
            this.NEW_QR.Location = new System.Drawing.Point(385, 52);
            this.NEW_QR.Name = "NEW_QR";
            this.NEW_QR.Size = new System.Drawing.Size(300, 300);
            this.NEW_QR.TabIndex = 6;
            this.NEW_QR.TabStop = false;
            // 
            // NEW_DEPARTMENT
            // 
            this.NEW_DEPARTMENT.FormattingEnabled = true;
            this.NEW_DEPARTMENT.ItemHeight = 23;
            this.NEW_DEPARTMENT.Location = new System.Drawing.Point(104, 127);
            this.NEW_DEPARTMENT.Name = "NEW_DEPARTMENT";
            this.NEW_DEPARTMENT.Size = new System.Drawing.Size(196, 29);
            this.NEW_DEPARTMENT.TabIndex = 5;
            // 
            // NEW_EMAIL
            // 
            this.NEW_EMAIL.Location = new System.Drawing.Point(104, 168);
            this.NEW_EMAIL.Name = "NEW_EMAIL";
            this.NEW_EMAIL.Size = new System.Drawing.Size(196, 23);
            this.NEW_EMAIL.TabIndex = 4;
            this.NEW_EMAIL.Click += new System.EventHandler(this.metroTextBox1_Click_1);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(15, 169);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(74, 19);
            this.metroLabel8.TabIndex = 3;
            this.metroLabel8.Text = "Email-ADD";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(15, 130);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(80, 19);
            this.metroLabel7.TabIndex = 3;
            this.metroLabel7.Text = "Department";
            // 
            // NEW_NAME
            // 
            this.NEW_NAME.Location = new System.Drawing.Point(104, 92);
            this.NEW_NAME.Name = "NEW_NAME";
            this.NEW_NAME.Size = new System.Drawing.Size(196, 23);
            this.NEW_NAME.TabIndex = 4;
            this.NEW_NAME.Click += new System.EventHandler(this.metroTextBox1_Click_1);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(15, 93);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(45, 19);
            this.metroLabel6.TabIndex = 3;
            this.metroLabel6.Text = "Name";
            // 
            // NEW_ID
            // 
            this.NEW_ID.Location = new System.Drawing.Point(104, 52);
            this.NEW_ID.Name = "NEW_ID";
            this.NEW_ID.Size = new System.Drawing.Size(196, 23);
            this.NEW_ID.TabIndex = 4;
            this.NEW_ID.Click += new System.EventHandler(this.metroTextBox1_Click_1);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(15, 53);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(76, 19);
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "ID_Number";
            // 
            // QR_SAVE
            // 
            this.QR_SAVE.Location = new System.Drawing.Point(610, 358);
            this.QR_SAVE.Name = "QR_SAVE";
            this.QR_SAVE.Size = new System.Drawing.Size(75, 23);
            this.QR_SAVE.TabIndex = 2;
            this.QR_SAVE.Text = "Save";
            this.QR_SAVE.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // NEW_ADDbtn
            // 
            this.NEW_ADDbtn.Location = new System.Drawing.Point(225, 210);
            this.NEW_ADDbtn.Name = "NEW_ADDbtn";
            this.NEW_ADDbtn.Size = new System.Drawing.Size(75, 23);
            this.NEW_ADDbtn.TabIndex = 2;
            this.NEW_ADDbtn.Text = "ADD";
            this.NEW_ADDbtn.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.metroLabel17);
            this.metroTabPage4.Controls.Add(this.metroComboBox1);
            this.metroTabPage4.Controls.Add(this.metroLabel12);
            this.metroTabPage4.Controls.Add(this.metroLabel11);
            this.metroTabPage4.Controls.Add(this.metroLabel13);
            this.metroTabPage4.Controls.Add(this.metroLabel10);
            this.metroTabPage4.Controls.Add(this.metroLabel9);
            this.metroTabPage4.Controls.Add(this.metroTextBox1);
            this.metroTabPage4.Controls.Add(this.metroButton5);
            this.metroTabPage4.Controls.Add(this.pictureBox1);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "Attendence";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.Click += new System.EventHandler(this.metroTabPage4_Click);
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(22, 15);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(56, 19);
            this.metroLabel17.TabIndex = 7;
            this.metroLabel17.Text = "Camera";
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Location = new System.Drawing.Point(84, 11);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(194, 29);
            this.metroComboBox1.TabIndex = 6;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroLabel12.Location = new System.Drawing.Point(481, 55);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(0, 0);
            this.metroLabel12.TabIndex = 5;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroLabel11.Location = new System.Drawing.Point(396, 55);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(50, 19);
            this.metroLabel11.TabIndex = 5;
            this.metroLabel11.Text = "DATE : ";
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroLabel13.Location = new System.Drawing.Point(718, 55);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(0, 0);
            this.metroLabel13.TabIndex = 5;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroLabel10.Location = new System.Drawing.Point(633, 55);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(49, 19);
            this.metroLabel10.TabIndex = 5;
            this.metroLabel10.Text = "TIME : ";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(396, 140);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(79, 19);
            this.metroLabel9.TabIndex = 5;
            this.metroLabel9.Text = "ID NUMBER";
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.Location = new System.Drawing.Point(396, 162);
            this.metroTextBox1.Multiline = true;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.Size = new System.Drawing.Size(260, 23);
            this.metroTextBox1.TabIndex = 4;
            // 
            // metroButton5
            // 
            this.metroButton5.Location = new System.Drawing.Point(3, 55);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(75, 23);
            this.metroButton5.TabIndex = 3;
            this.metroButton5.Text = "START";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 84);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(375, 344);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.dateTimePicker1);
            this.metroTabPage5.Controls.Add(this.metroLabel16);
            this.metroTabPage5.Controls.Add(this.metroLabel15);
            this.metroTabPage5.Controls.Add(this.metroLabel14);
            this.metroTabPage5.Controls.Add(this.metroTextBox2);
            this.metroTabPage5.Controls.Add(this.dataGridView2);
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage5.TabIndex = 4;
            this.metroTabPage5.Text = "View_Reports";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(558, 108);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(162, 20);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(3, 43);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(121, 19);
            this.metroLabel16.TabIndex = 4;
            this.metroLabel16.Text = "Attendence Record";
            this.metroLabel16.Click += new System.EventHandler(this.metroLabel15_Click);
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(476, 108);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(76, 19);
            this.metroLabel15.TabIndex = 4;
            this.metroLabel15.Text = "Select_Date";
            this.metroLabel15.Click += new System.EventHandler(this.metroLabel15_Click);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(495, 44);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(57, 19);
            this.metroLabel14.TabIndex = 4;
            this.metroLabel14.Text = "Enter_ID";
            // 
            // metroTextBox2
            // 
            this.metroTextBox2.Location = new System.Drawing.Point(558, 43);
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.Size = new System.Drawing.Size(162, 23);
            this.metroTextBox2.TabIndex = 3;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 65);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(432, 352);
            this.dataGridView2.TabIndex = 2;
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.Controls.Add(this.metroButton7);
            this.metroTabPage7.Controls.Add(this.metroTextBox4);
            this.metroTabPage7.Controls.Add(this.metroTextBox3);
            this.metroTabPage7.Controls.Add(this.metroLabel20);
            this.metroTabPage7.Controls.Add(this.metroLabel21);
            this.metroTabPage7.Controls.Add(this.metroLabel19);
            this.metroTabPage7.Controls.Add(this.metroLabel18);
            this.metroTabPage7.Controls.Add(this.metroButton6);
            this.metroTabPage7.Controls.Add(this.Emails);
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage7.TabIndex = 6;
            this.metroTabPage7.Text = "Send_Email";
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            this.metroTabPage7.Click += new System.EventHandler(this.metroTabPage7_Click);
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(807, 424);
            this.metroTabPage8.TabIndex = 7;
            this.metroTabPage8.Text = "Get_Copy";
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            // 
            // Emails
            // 
            this.Emails.FormattingEnabled = true;
            this.Emails.Location = new System.Drawing.Point(3, 152);
            this.Emails.Name = "Emails";
            this.Emails.Size = new System.Drawing.Size(187, 251);
            this.Emails.TabIndex = 2;
            // 
            // metroButton6
            // 
            this.metroButton6.Location = new System.Drawing.Point(115, 38);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(75, 23);
            this.metroButton6.TabIndex = 3;
            this.metroButton6.Text = "SELECT";
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(4, 39);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(105, 19);
            this.metroLabel18.TabIndex = 4;
            this.metroLabel18.Text = "Select Recipients";
            this.metroLabel18.Click += new System.EventHandler(this.metroLabel18_Click);
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(261, 40);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(51, 19);
            this.metroLabel19.TabIndex = 4;
            this.metroLabel19.Text = "Subject";
            // 
            // metroTextBox3
            // 
            this.metroTextBox3.Location = new System.Drawing.Point(316, 37);
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.Size = new System.Drawing.Size(439, 23);
            this.metroTextBox3.TabIndex = 5;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.metroLabel20.Location = new System.Drawing.Point(4, 130);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(120, 19);
            this.metroLabel20.TabIndex = 4;
            this.metroLabel20.Text = "Selected Recipients";
            this.metroLabel20.Click += new System.EventHandler(this.metroLabel20_Click);
            // 
            // metroTextBox4
            // 
            this.metroTextBox4.BackColor = System.Drawing.SystemColors.Control;
            this.metroTextBox4.Location = new System.Drawing.Point(320, 97);
            this.metroTextBox4.Multiline = true;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.Size = new System.Drawing.Size(439, 186);
            this.metroTextBox4.TabIndex = 6;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(254, 97);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(60, 19);
            this.metroLabel21.TabIndex = 4;
            this.metroLabel21.Text = "Message";
            // 
            // metroButton7
            // 
            this.metroButton7.Location = new System.Drawing.Point(680, 314);
            this.metroButton7.Name = "metroButton7";
            this.metroButton7.Size = new System.Drawing.Size(75, 23);
            this.metroButton7.TabIndex = 7;
            this.metroButton7.Text = "Send";
            this.metroButton7.Click += new System.EventHandler(this.metroButton7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 543);
            this.Controls.Add(this.metroTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "Form1";
            this.Text = "Timex";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NEW_QR)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.metroTabPage7.ResumeLayout(false);
            this.metroTabPage7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroTabPage metroTabPage6;
        private MetroFramework.Controls.MetroTabPage metroTabPage7;
        private MetroFramework.Controls.MetroTabPage metroTabPage8;
        private MetroFramework.Controls.MetroTextBox tbID;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroComboBox combodepartment;
        private MetroFramework.Controls.MetroTextBox tbemail;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox tbname;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroTextBox NEW_ID;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton NEW_ADDbtn;
        private MetroFramework.Controls.MetroComboBox NEW_DEPARTMENT;
        private MetroFramework.Controls.MetroTextBox NEW_EMAIL;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox NEW_NAME;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.PictureBox NEW_QR;
        private MetroFramework.Controls.MetroButton QR_SAVE;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroButton metroButton5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private System.Windows.Forms.ListBox Emails;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroButton metroButton6;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroButton metroButton7;
    }
}

